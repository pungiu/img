module.exports = {
    php: "/usr/bin/php"              // macOS/Ubuntu
}